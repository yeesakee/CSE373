package datastructures.graphs;

import datastructures.dictionaries.ChainedHashDictionary;
import datastructures.dictionaries.IDictionary;
import datastructures.dictionaries.KVPair;
import datastructures.disjointsets.ArrayDisjointSets;
import datastructures.disjointsets.IDisjointSets;
import datastructures.lists.DoubleLinkedList;
import datastructures.lists.IList;
import datastructures.priorityqueues.ArrayHeapPriorityQueue;
import datastructures.priorityqueues.IPriorityQueue;
import datastructures.sets.ChainedHashSet;
import datastructures.sets.ISet;
import misc.Sorter;

import java.util.Iterator;

/**
 * Represents an undirected, weighted graph, possibly containing self-loops, parallel edges,
 * and unconnected components.
 *
 * @param <V> the type of the vertices
 * @param <E> the type of the additional data contained in edges
 *
 * Note: This class is not meant to be a full-featured way of representing a graph.
 * We stick with supporting just a few, core set of operations needed for the
 * remainder of the project.
 */
public class Graph<V, E> {
    IDictionary<V, IList<Edge<V, E>>> dict;
    int edges;
    /**
     * Constructs a new empty graph.
     */
    public Graph() {
        dict = new ChainedHashDictionary<>();
        edges = 0;
    }

    /**
     * Adds a vertex to this graph. If the vertex is already in the graph, does nothing.
     */
    public void addVertex(V vertex) {
        if (!dict.containsKey((vertex))) {
            dict.put(vertex, new DoubleLinkedList<>());
        }
    }

    /**
     * Adds a new edge to the graph, with null data.
     *
     * Every time this method is (successfully) called, a unique edge is added to the graph; even if
     * another edge between the same vertices and with the same weight and data already exists, a
     * new edge will be created and added (where `newEdge.equals(oldEdge)` is false).
     *
     * @throws IllegalArgumentException  if `weight` is null (YOU MEANT NEGATIVE??)
     * @throws IllegalArgumentException  if either vertex is not contained in the graph
     */
    public void addEdge(V vertex1, V vertex2, double weight) { this.addEdge(vertex1, vertex2, weight, null); }

    /**
     * Adds a new edge to the graph with the given data.
     *
     * Every time this method is (successfully) called, a unique edge is added to the graph; even if
     * another edge between the same vertices and with the same weight and data already exists, a
     * new edge will be created and added (where `newEdge.equals(oldEdge)` is false).
     *
     * @throws IllegalArgumentException  if `weight` is null (YOU MEANT NEGATIVE??)
     * @throws IllegalArgumentException  if either vertex is not contained in the graph
     */
    public void addEdge(V vertex1, V vertex2, double weight, E data) {
        if (weight < 0 || !dict.containsKey(vertex1) || !dict.containsKey(vertex2)) {
            throw new IllegalArgumentException();
        }
        edges += 1;
        Edge<V, E> edge = new Edge(vertex1, vertex2, weight, data);
        dict.get(vertex1).add(edge);
        dict.get(vertex2).add(edge);
    }

    /**
     * Returns the number of vertices contained within this graph.
     */
    public int numVertices() {
        return dict.size();
    }

    /**
     * Returns the number of edges contained within this graph.
     */
    public int numEdges() {
        return edges;
    }

    /**
     * Returns the set of all edges that make up the minimum spanning tree of this graph.
     *
     * If there exists multiple valid MSTs, returns any one of them.
     *
     * Precondition: the graph does not contain any unconnected components.
     */
    public ISet<Edge<V, E>> findMinimumSpanningTree() {
        ISet<Edge<V, E>> minSpanTree = new ChainedHashSet<>();
        IDisjointSets<V> set = new ArrayDisjointSets<>();

        IList<Edge<V, E>> edgeList = new DoubleLinkedList<>();

        for (KVPair<V, IList<Edge<V, E>>> vertex : dict) {
            IList<Edge<V, E>> ed = vertex.getValue();
            for (Edge<V, E> edge: ed) {
                if (!edgeList.contains(edge)) {
                    edgeList.add(edge);
                }
            }
        }

        IList<Edge<V, E>> sortedEdges = Sorter.topKSort(numEdges(), edgeList);

        for (KVPair<V, IList<Edge<V, E>>> vertex : dict) {
            set.makeSet(vertex.getKey());
        }

        for (Edge<V, E> edge : sortedEdges) {
            if (set.findSet(edge.getVertex1()) != set.findSet(edge.getVertex2())) {
                set.union(edge.getVertex1(), edge.getVertex2());
                minSpanTree.add(edge);
            }
        }
        
        return minSpanTree;
    }

    /**
     * Returns the edges that make up the shortest path from `start` to `end`.
     *
     * The first edge in the output list will be the edge leading out of the `start` node; the last
     * edge in the output list will be the edge connecting to the `end` node.
     *
     * Returns an empty list if the start and end vertices are the same.
     *
     * @throws NoPathExistsException  if there does not exist a path from `start` to `end`
     * @throws IllegalArgumentException if `start` or `end` is null or not in the graph
     */
    public IList<Edge<V, E>> findShortestPathBetween(V start, V end) {
        if (start == null || end == null) {
            throw new IllegalArgumentException();
        }

        if (start.equals(end)) {
            return new DoubleLinkedList<>();
        }
        IList<Edge<V, E>> result = new DoubleLinkedList<>();
        IPriorityQueue<ComparableVertex<V, E>> prio = new ArrayHeapPriorityQueue<>();
        IDictionary<V, ComparableVertex<V, E>> dictionary = new ChainedHashDictionary<>();

        for (KVPair<V, IList<Edge<V, E>>> vertex : dict) {
            double dis = Double.POSITIVE_INFINITY;
            if (vertex.getKey().equals(start)) {
                dis = 0;
            }
            ComparableVertex<V, E> com = new ComparableVertex(dis, null, vertex.getValue(), vertex.getKey());
            dictionary.put(vertex.getKey(), com);
            prio.add(com);
        }

        helperMethod(dictionary, prio);

        ComparableVertex<V, E> cVertex = dictionary.get(end);
        V c = cVertex.vertex;
        ComparableVertex<V, E> c2 = cVertex.comVertex;
        if (c2 == null) {
            cVertex = dictionary.get(start);
        }
        c2 = cVertex.comVertex;
        if (c2 == null) {
            throw new NoPathExistsException();
        }
        V c3 = c2.vertex;

        IList<Edge<V, E>> list = cVertex.list;
        Iterator<Edge<V, E>> itr = list.iterator();

        Edge<V, E> parallel = null;
        while (!c.equals(start)) {
            while (itr.hasNext()) {
                Edge<V, E> ed = itr.next();
                if ((c.equals(ed.getVertex1()) && c3.equals(ed.getVertex2()) ||
                        c3.equals(ed.getVertex1()) && c.equals(ed.getVertex2()))) {
                    if (parallel != null) {
                        if (parallel.getWeight() > ed.getWeight()) {
                            int index = result.indexOf(parallel);
                            if (index != -1) {
                                result.set(index, ed);
                            }
                            parallel = ed;
                        }
                    }
                    else if (!ed.getVertex1().equals(ed.getVertex2())) {
                        parallel = ed;
                        result.insert(0, ed);
                    }
                }
            }
            cVertex = dictionary.get(c3);
            c = cVertex.vertex;
            itr = dictionary.get(c).list.iterator();
            if (c2.comVertex != null) {
                c3 = c2.comVertex.vertex;
                c2 = cVertex;
            }
            parallel = null;
        }
        return result;
    }

    private void helperMethod(IDictionary<V, ComparableVertex<V, E>> dictionary,
                              IPriorityQueue<ComparableVertex<V, E>> prio) {
        ComparableVertex<V, E> vertex = null;
        while (!prio.isEmpty()) {
            vertex = prio.removeMin();
            for (Edge<V, E> edge: vertex.list) {
                double weight = edge.getWeight();
                V compareVertex = edge.getVertex2();
                if (compareVertex.equals(vertex.vertex)) {
                    compareVertex = edge.getVertex1();
                }
                double compare = dictionary.get(compareVertex).distance;
                if (vertex.distance + weight < compare) {
                    ComparableVertex<V, E> com = new ComparableVertex(vertex.distance + weight, vertex,
                            dict.get(compareVertex), compareVertex);
                    prio.replace(dictionary.get(compareVertex), com);
                    dictionary.remove(compareVertex);
                    dictionary.put(compareVertex, com);
                }
            }
        }
    }

    private static class ComparableVertex<V, E>
            implements Comparable<ComparableVertex<V, E>> {

        final double distance;
        final ComparableVertex<V, E> comVertex;
        final V vertex;
        final IList<Edge<V, E>> list;

        public ComparableVertex(double distance, ComparableVertex<V, E> comVertex, IList<Edge<V, E>> list, V vertex) {
            this.distance = distance;
            this.comVertex = comVertex;
            this.vertex = vertex;
            this.list = list;
        }

        public int compareTo(ComparableVertex<V, E> vertex1) {
            if (vertex1.distance < distance) {
                return 1;
            }
            else if (vertex1.distance == distance) {
                return 0;
            }
            return -1;
        }
    }
}
