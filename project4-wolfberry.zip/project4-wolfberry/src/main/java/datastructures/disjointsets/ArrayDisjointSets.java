package datastructures.disjointsets;

import datastructures.dictionaries.ChainedHashDictionary;
import datastructures.dictionaries.IDictionary;

/**
 * @see IDisjointSets for more details.
 */
public class ArrayDisjointSets<T> implements IDisjointSets<T> {
    // Do NOT rename or delete this field. We will be inspecting it directly in our private tests.
    int[] pointers;
    private IDictionary<T, Integer> dict;
    private int index;
    /*
    However, feel free to add more fields and private helper methods. You will probably need to
    add one or two more fields in order to successfully implement this class.
    */

    public ArrayDisjointSets() {
        pointers = new int[10];
        dict = new ChainedHashDictionary<>();
        index = 0;
    }

    @Override
    public void makeSet(T item) {
        if (dict.containsKey(item)) {
            throw new IllegalArgumentException();
        }

        if (index == pointers.length) {
            int[] resize = new int[pointers.length * 2];
            for (int i = 0; i < pointers.length; i++) {
                resize[i] = pointers[i];
            }
            pointers = resize;
        }
        pointers[index] = -1;
        dict.put(item, index);
        index += 1;
    }

    @Override
    public int findSet(T item) {
        if (!dict.containsKey(item)) {
            throw new IllegalArgumentException();
        }

        return findRepresent(dict.get(item));
    }

    @Override
    public boolean union(T item1, T item2) {
        if (!dict.containsKey(item1) || !dict.containsKey(item2)) {
            throw new IllegalArgumentException();
        }

        int index1 = findRepresent(dict.get(item1));
        int index2 = findRepresent(dict.get(item2));

        if (index1 == index2) {
            return false;
        }

        if (pointers[index1] <= pointers[index2]) {
            if (pointers[index1] == pointers[index2]) {
                pointers[index1] = pointers[index1] - 1;
            }

            pointers[index2] = index1;
        }
        else {
            pointers[index1] = index2;
        }

        return true;
    }

    private int findRepresent(int start) {
        int index1 = start;
        if (start >= 0) {
            start = pointers[start];
            if (start >= 0) {
                start = findRepresent(start);
                pointers[index1] = start;
                return start;
            }
        }
        return index1;
    }
}
