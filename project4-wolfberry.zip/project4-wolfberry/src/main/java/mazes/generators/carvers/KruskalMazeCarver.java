package mazes.generators.carvers;

import datastructures.graphs.Edge;
import datastructures.graphs.Graph;
import datastructures.sets.ChainedHashSet;
import datastructures.sets.ISet;
import mazes.entities.Maze;
import mazes.entities.Room;
import mazes.entities.Wall;
import java.util.Iterator;
import java.util.Random;

/**
 * Carves out a maze based on Kruskal's algorithm.
 *
 * See the spec for more details.
 */
public class KruskalMazeCarver implements MazeCarver {
    /**
     * A helper method for constructing a new `Graph`.
     */
    protected Graph<Room, Wall> makeGraph() {
        /*
        Do not change this method; it only exists so that we can override it during grading to test
        your code using our correct version of `Graph`.

        Make sure to use this instead of calling the `Graph` constructor yourself; otherwise, you
        may end up losing extra points if your `Graph` does not behave correctly.
         */
        return new Graph<>();
    }

    @Override
    public ISet<Wall> returnWallsToRemove(Maze maze) {
        Random rand = new Random();
        Graph<Room, Wall> graph = makeGraph();

        ISet<Wall> walls = maze.getRemovableWalls();
        Iterator<Wall> itr = walls.iterator();
        Room room = null;

        for (Room r: maze.getRooms()) {
            graph.addVertex(r);
        }

        while (itr.hasNext()) {
            double weight = rand.nextDouble();
            if (weight < 0) {
                weight *= -1;
            }
            Wall wall = itr.next();
            graph.addEdge(wall.getRoom1(), wall.getRoom2(), weight, wall);
        }

        ISet<Wall> set = new ChainedHashSet<>();
        Iterator<Edge<Room, Wall>> itrs = graph.findMinimumSpanningTree().iterator();
        while (itrs.hasNext()) {
            set.add(itrs.next().getData());
        }

        return set;
    }
}
