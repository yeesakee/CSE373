package mazes;

import mazes.gui.MainWindow;

public class Main {
    /**
     * Starts the maze generator/solver application.
     */
    public static void main(String[] args) {
        MainWindow.launch();
    }
}
